# ClickFriend Mod — Minecraft 1.21.4 (Fabric)

Highlight your friends on any server with custom colors, ESP boxes, and glow effects!  
Press **F12** to open the Friend Manager GUI at any time.

---

## Features

- **F12 GUI** — Open the Friend Manager from anywhere, even mid-game
- **Per-friend colors** — Assign any color to each friend (6 quick presets + custom)
- **ESP Box** — Colored bounding box drawn around each friend's hitbox
- **Glow toggle** — Works via Minecraft's built-in glow/outline system
- **Name tag toggle** — Highlights the friend's name above their head
- **Enable/Disable** per friend — Toggle a friend without removing them
- **Persistent config** — Settings saved to `.minecraft/config/clickfriend.json`

---

## Installation

### Requirements
- Minecraft **1.21.4**
- [Fabric Loader](https://fabricmc.net/use/installer/) `0.16.10+`
- [Fabric API](https://modrinth.com/mod/fabric-api) `0.119.0+1.21.4`
- Java **21**

### Steps
1. Install Fabric Loader for 1.21.4
2. Download Fabric API and put it in your `mods/` folder
3. Put `clickfriend-1.0.0.jar` into your `mods/` folder
4. Launch Minecraft with the Fabric profile

---

## Building from Source

> You need JDK 21 installed.

```bash
git clone <this repo>
cd clickfriend
./gradlew build
```

The built jar will be in `build/libs/clickfriend-1.0.0.jar`

On **Windows**, use `gradlew.bat build` instead.

---

## Usage

### Adding a Friend
1. Press **F12** in-game
2. Type the player's **exact username** in the input box
3. Pick a color preset (green is default)
4. Click **+ Add Friend**

### Removing a Friend
1. Press **F12**
2. Find the friend in the list
3. Click **Remove**

### Toggling Features
At the top of the GUI you can toggle:
- **Glow** — Glow outline effect (requires Optifine/Sodium to be visible in some cases)
- **ESP** — Colored box drawn around the friend
- **Tag** — Name highlight above their head

### Config File
Location: `.minecraft/config/clickfriend.json`

```json
{
  "friends": [
    {
      "username": "Steve",
      "color": -16711936,
      "enabled": true
    }
  ],
  "showGlowEffect": true,
  "showNameTag": true,
  "showESP": true,
  "espLineWidth": 2.0,
  "showOnlyThroughWalls": false
}
```

Color is stored as a packed ARGB int. Use a color picker to get the hex value and convert it.
Common colors:
- Green: `-16711936` (0xFF00FF00)
- Blue: `0xFF44AAFF`
- Red: `0xFFFF4444`

---

## Project Structure

```
src/main/java/com/clickfriend/
├── ClickFriendClient.java       ← Main entrypoint, keybind registration
├── config/
│   └── FriendConfig.java        ← JSON config, friend list management
├── gui/
│   └── FriendScreen.java        ← F12 GUI screen
├── mixin/
│   ├── PlayerEntityRendererMixin.java  ← Player render hook
│   └── GameRendererMixin.java          ← World render hook for ESP
└── render/
    └── FriendRenderer.java      ← ESP box drawing logic
```

---

## Notes

- This mod is **client-side only** — no server install needed
- Works on any server including Funtime (FunTime)
- The ESP box is drawn in the friend's assigned color
- If you use **Sodium**, the glow effect may behave differently — ESP box still works
- The mod does **not** modify any server packets; it only reads player data visible to your client

---

## License
MIT — Use freely, modify, share.
