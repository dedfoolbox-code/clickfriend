package com.clickfriend.gui;

import com.clickfriend.config.FriendConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.List;

public class FriendScreen extends Screen {

    private final Screen parent;
    private FriendConfig config;

    // Input fields
    private TextFieldWidget usernameField;

    // Color picker state
    private int selectedColor = 0xFF00FF00; // Default: green
    private int colorR = 0, colorG = 255, colorB = 0;

    // Scroll offset for friend list
    private int scrollOffset = 0;
    private static final int ENTRY_HEIGHT = 26;
    private static final int LIST_Y = 160;
    private static final int LIST_MAX_VISIBLE = 6;

    // Panels
    private static final int PANEL_W = 420;
    private static final int PANEL_H = 360;

    public FriendScreen(Screen parent) {
        super(Text.literal("§a✦ ClickFriend §7- §fFriend Manager"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        config = FriendConfig.getInstance();

        int cx = this.width / 2;
        int panelX = cx - PANEL_W / 2;
        int panelY = this.height / 2 - PANEL_H / 2;

        // Username input
        usernameField = new TextFieldWidget(
                this.textRenderer,
                panelX + 16, panelY + 56,
                200, 20,
                Text.literal("Nickname")
        );
        usernameField.setPlaceholder(Text.literal("§7Enter username..."));
        usernameField.setMaxLength(32);
        this.addDrawableChild(usernameField);

        // Color preset buttons
        int[] presetColors = {
                0xFF00FF44, // Green
                0xFF44AAFF, // Blue
                0xFFFF4444, // Red
                0xFFFFFF00, // Yellow
                0xFFFF44FF, // Purple
                0xFFFFFFFF, // White
        };
        String[] presetLabels = {"§aGreen", "§9Blue", "§cRed", "§eYellow", "§dPurple", "§fWhite"};

        for (int i = 0; i < presetColors.length; i++) {
            final int color = presetColors[i];
            final int idx = i;
            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal(presetLabels[i]),
                    btn -> {
                        selectedColor = color;
                        colorR = (color >> 16) & 0xFF;
                        colorG = (color >> 8) & 0xFF;
                        colorB = color & 0xFF;
                    })
                    .dimensions(panelX + 228 + (idx % 3) * 60, panelY + 56 + (idx / 3) * 22, 58, 20)
                    .build());
        }

        // Add Friend button
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("§a+ Add Friend"),
                btn -> addFriend())
                .dimensions(panelX + 16, panelY + 116, 100, 20)
                .build());

        // Settings toggles
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal(config.showGlowEffect ? "§aGlow: ON" : "§cGlow: OFF"),
                btn -> {
                    config.showGlowEffect = !config.showGlowEffect;
                    config.save();
                    btn.setMessage(Text.literal(config.showGlowEffect ? "§aGlow: ON" : "§cGlow: OFF"));
                })
                .dimensions(panelX + 122, panelY + 116, 80, 20)
                .build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal(config.showESP ? "§aESP: ON" : "§cESP: OFF"),
                btn -> {
                    config.showESP = !config.showESP;
                    config.save();
                    btn.setMessage(Text.literal(config.showESP ? "§aESP: ON" : "§cESP: OFF"));
                })
                .dimensions(panelX + 208, panelY + 116, 70, 20)
                .build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal(config.showNameTag ? "§aTag: ON" : "§cTag: OFF"),
                btn -> {
                    config.showNameTag = !config.showNameTag;
                    config.save();
                    btn.setMessage(Text.literal(config.showNameTag ? "§aTag: ON" : "§cTag: OFF"));
                })
                .dimensions(panelX + 284, panelY + 116, 70, 20)
                .build());

        // Close button
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("§cClose"),
                btn -> this.close())
                .dimensions(panelX + PANEL_W - 70, panelY + PANEL_H - 28, 60, 20)
                .build());

        // Scroll buttons
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("§f▲"),
                btn -> { if (scrollOffset > 0) scrollOffset--; })
                .dimensions(panelX + PANEL_W - 28, panelY + LIST_Y - panelY, 22, 14)
                .build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("§f▼"),
                btn -> {
                    int max = Math.max(0, config.friends.size() - LIST_MAX_VISIBLE);
                    if (scrollOffset < max) scrollOffset++;
                })
                .dimensions(panelX + PANEL_W - 28, panelY + LIST_Y - panelY + LIST_MAX_VISIBLE * ENTRY_HEIGHT - 14, 22, 14)
                .build());
    }

    private void addFriend() {
        String name = usernameField.getText().trim();
        if (!name.isEmpty()) {
            config.addFriend(name, selectedColor);
            usernameField.setText("");
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Dim background
        this.renderBackground(context, mouseX, mouseY, delta);

        int cx = this.width / 2;
        int panelX = cx - PANEL_W / 2;
        int panelY = this.height / 2 - PANEL_H / 2;

        // Main panel background
        context.fill(panelX, panelY, panelX + PANEL_W, panelY + PANEL_H, 0xDD111122);
        // Border
        drawBorder(context, panelX, panelY, PANEL_W, PANEL_H, 0xFF00FF88);

        // Title bar
        context.fill(panelX, panelY, panelX + PANEL_W, panelY + 24, 0xDD002233);
        context.drawCenteredTextWithShadow(textRenderer, "§a✦ §fClickFriend §7- §bFriend Manager", cx, panelY + 8, 0xFFFFFF);

        // Section: Add Friend
        context.drawTextWithShadow(textRenderer, "§7Username:", panelX + 16, panelY + 44, 0xAAAAAA);
        context.drawTextWithShadow(textRenderer, "§7Color Preset:", panelX + 228, panelY + 44, 0xAAAAAA);

        // Color preview box
        context.fill(panelX + 358, panelY + 96, panelX + 400, panelY + 112, 0xFF000000);
        context.fill(panelX + 359, panelY + 97, panelX + 399, panelY + 111, selectedColor | 0xFF000000);

        // Divider
        context.fill(panelX + 8, panelY + 142, panelX + PANEL_W - 8, panelY + 143, 0xFF00FF88);
        context.drawTextWithShadow(textRenderer, "§b● Friend List", panelX + 16, panelY + 148, 0x00FF88);

        // Friend list
        renderFriendList(context, panelX, panelY, mouseX, mouseY);

        // Render widgets
        super.render(context, mouseX, mouseY, delta);
    }

    private void renderFriendList(DrawContext context, int panelX, int panelY, int mouseX, int mouseY) {
        List<FriendConfig.FriendEntry> friends = config.friends;
        int listX = panelX + 8;
        int listY = panelY + LIST_Y;
        int listW = PANEL_W - 40;

        // Clipping region (simulated via fill)
        for (int i = 0; i < LIST_MAX_VISIBLE; i++) {
            int idx = i + scrollOffset;
            if (idx >= friends.size()) break;

            FriendConfig.FriendEntry entry = friends.get(idx);
            int entryY = listY + i * ENTRY_HEIGHT;
            int rowColor = (idx % 2 == 0) ? 0x22FFFFFF : 0x11FFFFFF;
            boolean hovered = mouseX >= listX && mouseX <= listX + listW
                    && mouseY >= entryY && mouseY <= entryY + ENTRY_HEIGHT - 2;

            if (hovered) rowColor = 0x33FFFFFF;

            context.fill(listX, entryY, listX + listW, entryY + ENTRY_HEIGHT - 2, rowColor);

            // Color dot
            int dotColor = entry.color | 0xFF000000;
            context.fill(listX + 6, entryY + 7, listX + 16, entryY + 17, 0xFF000000);
            context.fill(listX + 7, entryY + 8, listX + 15, entryY + 16, dotColor);

            // Username
            String status = entry.enabled ? "§a" : "§7";
            context.drawTextWithShadow(textRenderer, status + entry.username, listX + 22, entryY + 8, 0xFFFFFF);

            // Buttons: Toggle, Remove
            int btnX = listX + listW - 116;
            // Toggle button
            boolean tog = entry.enabled;
            context.fill(btnX, entryY + 4, btnX + 54, entryY + 20, tog ? 0xFF004400 : 0xFF440000);
            context.drawBorder(btnX, entryY + 4, 54, 16, tog ? 0xFF00AA00 : 0xFFAA0000);
            context.drawCenteredTextWithShadow(textRenderer,
                    tog ? "§aEnabled" : "§cDisabled",
                    btnX + 27, entryY + 8, 0xFFFFFF);

            // Remove button
            int remX = btnX + 60;
            context.fill(remX, entryY + 4, remX + 48, entryY + 20, 0xFF440000);
            context.drawBorder(remX, entryY + 4, 48, 16, 0xFFAA0000);
            context.drawCenteredTextWithShadow(textRenderer, "§cRemove", remX + 24, entryY + 8, 0xFFFFFF);
        }

        // Empty state
        if (friends.isEmpty()) {
            context.drawCenteredTextWithShadow(textRenderer,
                    "§7No friends added yet. Add one above!",
                    panelX + PANEL_W / 2, listY + 30, 0x888888);
        }

        // Scroll indicator
        if (friends.size() > LIST_MAX_VISIBLE) {
            int total = friends.size();
            int trackH = LIST_MAX_VISIBLE * ENTRY_HEIGHT;
            int thumbH = Math.max(20, trackH * LIST_MAX_VISIBLE / total);
            int thumbY = listY + (trackH - thumbH) * scrollOffset / Math.max(1, total - LIST_MAX_VISIBLE);
            context.fill(panelX + PANEL_W - 30, listY, panelX + PANEL_W - 22, listY + trackH, 0x44FFFFFF);
            context.fill(panelX + PANEL_W - 30, thumbY, panelX + PANEL_W - 22, thumbY + thumbH, 0xFF00FF88);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Handle friend list button clicks
        int cx = this.width / 2;
        int panelX = cx - PANEL_W / 2;
        int panelY = this.height / 2 - PANEL_H / 2;
        int listX = panelX + 8;
        int listY = panelY + LIST_Y;
        int listW = PANEL_W - 40;

        List<FriendConfig.FriendEntry> friends = config.friends;
        for (int i = 0; i < LIST_MAX_VISIBLE; i++) {
            int idx = i + scrollOffset;
            if (idx >= friends.size()) break;

            int entryY = listY + i * ENTRY_HEIGHT;
            FriendConfig.FriendEntry entry = friends.get(idx);

            int btnX = listX + listW - 116;
            // Toggle
            if (mouseX >= btnX && mouseX <= btnX + 54 && mouseY >= entryY + 4 && mouseY <= entryY + 20) {
                config.toggleFriend(entry.username);
                this.clearAndInit();
                return true;
            }
            // Remove
            int remX = btnX + 60;
            if (mouseX >= remX && mouseX <= remX + 48 && mouseY >= entryY + 4 && mouseY <= entryY + 20) {
                config.removeFriend(entry.username);
                if (scrollOffset > 0 && scrollOffset >= config.friends.size()) scrollOffset--;
                this.clearAndInit();
                return true;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int max = Math.max(0, config.friends.size() - LIST_MAX_VISIBLE);
        if (verticalAmount < 0) { if (scrollOffset < max) scrollOffset++; }
        else { if (scrollOffset > 0) scrollOffset--; }
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // F12 closes the screen
        if (keyCode == 301) { // GLFW_KEY_F12 = 301
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    private void drawBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }
}
