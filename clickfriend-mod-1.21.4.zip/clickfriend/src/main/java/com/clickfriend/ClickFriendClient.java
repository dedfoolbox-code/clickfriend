package com.clickfriend;

import com.clickfriend.config.FriendConfig;
import com.clickfriend.gui.FriendScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ClickFriendClient implements ClientModInitializer {

    public static final String MOD_ID = "clickfriend";

    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        // Load config on startup
        FriendConfig.getInstance();

        // Register F12 keybind
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.clickfriend.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F12,
                "category.clickfriend"
        ));

        // Handle keybind press
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new FriendScreen(null));
                }
            }
        });

        System.out.println("[ClickFriend] Mod loaded! Press F12 to open friend manager.");
    }

    public static KeyBinding getOpenGuiKey() {
        return openGuiKey;
    }
}
