package com.clickfriend.mixin;

import com.clickfriend.config.FriendConfig;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public class PlayerEntityRendererMixin {

    /**
     * Inject at the start of the render method to apply friend highlighting.
     * We mark the player as "glowing" if they are on our friend list and glow is enabled.
     */
    @Inject(
        method = "render(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
        at = @At("HEAD")
    )
    private void onRenderHead(
            PlayerEntityRenderState state,
            float yaw,
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci
    ) {
        // Note: actual glow color override is handled via the GlowingOverlayRenderer through the ESP system
        // This mixin is a hook point; additional logic is handled in GameRendererMixin and the render helper
    }
}
