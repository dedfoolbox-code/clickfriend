package com.clickfriend.mixin;

import com.clickfriend.config.FriendConfig;
import com.clickfriend.render.FriendRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {

    /**
     * Injects at the end of the world render to draw ESP boxes for friends.
     */
    @Inject(
        method = "renderWorld",
        at = @At("TAIL")
    )
    private void onRenderWorldLast(float tickDelta, long limitTime, MatrixStack matrices, CallbackInfo ci) {
        FriendConfig config = FriendConfig.getInstance();
        if (!config.showESP) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) return;

        try {
            FriendRenderer.render(matrices, tickDelta);
        } catch (Exception e) {
            // Silently fail to avoid crashing the game
        }
    }
}
