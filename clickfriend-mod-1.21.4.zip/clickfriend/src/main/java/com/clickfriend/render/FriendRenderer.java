package com.clickfriend.render;

import com.clickfriend.config.FriendConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Handles drawing colored ESP boxes and name tags around friend players.
 * Called from the WorldRenderLastCallback event.
 */
public class FriendRenderer {

    public static void render(MatrixStack matrices, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) return;

        FriendConfig config = FriendConfig.getInstance();
        if (!config.showESP) return;

        Camera camera = client.gameRenderer.getCamera();
        Vec3d camPos = camera.getPos();

        List<? extends PlayerEntity> players = client.world.getPlayers();

        Tessellator tessellator = Tessellator.getInstance();

        for (PlayerEntity player : players) {
            // Skip self
            if (player == client.player) continue;

            String name = player.getNameForScoreboard();
            FriendConfig.FriendEntry entry = config.getFriend(name);
            if (entry == null || !entry.enabled) continue;

            // Interpolate position
            double x = player.prevX + (player.getX() - player.prevX) * tickDelta - camPos.x;
            double y = player.prevY + (player.getY() - player.prevY) * tickDelta - camPos.y;
            double z = player.prevZ + (player.getZ() - player.prevZ) * tickDelta - camPos.z;

            // Player hitbox: 0.6 wide, 1.8 tall
            double hw = player.getWidth() / 2.0 + 0.05;
            double ht = player.getHeight() + 0.1;

            int color = entry.color;
            float r = ((color >> 16) & 0xFF) / 255f;
            float g = ((color >> 8)  & 0xFF) / 255f;
            float b = (color & 0xFF) / 255f;
            float a = 0.8f;

            matrices.push();
            matrices.translate(x, y, z);

            drawBox(matrices, tessellator, -hw, 0, -hw, hw, ht, hw, r, g, b, a);

            matrices.pop();
        }
    }

    private static void drawBox(MatrixStack matrices, Tessellator tessellator,
                                double x1, double y1, double z1,
                                double x2, double y2, double z2,
                                float r, float g, float b, float a) {
        Matrix4f mat = matrices.peek().getPositionMatrix();
        BufferBuilder buf = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

        // Bottom face
        line(buf, mat, x1, y1, z1, x2, y1, z1, r, g, b, a);
        line(buf, mat, x2, y1, z1, x2, y1, z2, r, g, b, a);
        line(buf, mat, x2, y1, z2, x1, y1, z2, r, g, b, a);
        line(buf, mat, x1, y1, z2, x1, y1, z1, r, g, b, a);

        // Top face
        line(buf, mat, x1, y2, z1, x2, y2, z1, r, g, b, a);
        line(buf, mat, x2, y2, z1, x2, y2, z2, r, g, b, a);
        line(buf, mat, x2, y2, z2, x1, y2, z2, r, g, b, a);
        line(buf, mat, x1, y2, z2, x1, y2, z1, r, g, b, a);

        // Vertical edges
        line(buf, mat, x1, y1, z1, x1, y2, z1, r, g, b, a);
        line(buf, mat, x2, y1, z1, x2, y2, z1, r, g, b, a);
        line(buf, mat, x2, y1, z2, x2, y2, z2, r, g, b, a);
        line(buf, mat, x1, y1, z2, x1, y2, z2, r, g, b, a);

        BuiltBuffer built = buf.endNullable();
        if (built != null) {
            // Submit directly via RenderSystem
            RenderSystem.disableDepthTest();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.lineWidth(2.0f);

            BuiltBuffer.DrawParameters params = built.getDrawParameters();
            // Use the tessellator to draw
            tessellator.draw(built);

            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
        }
    }

    private static void line(BufferBuilder buf, Matrix4f mat,
                              double x1, double y1, double z1,
                              double x2, double y2, double z2,
                              float r, float g, float b, float a) {
        buf.vertex(mat, (float) x1, (float) y1, (float) z1).color(r, g, b, a);
        buf.vertex(mat, (float) x2, (float) y2, (float) z2).color(r, g, b, a);
    }
}
