package com.clickfriend.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class FriendConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("clickfriend.json");

    private static FriendConfig INSTANCE;

    // Settings
    public List<FriendEntry> friends = new ArrayList<>();
    public boolean showGlowEffect = true;
    public boolean showNameTag = true;
    public boolean showESP = true;
    public float espLineWidth = 2.0f;
    public boolean showOnlyThroughWalls = false;

    public static class FriendEntry {
        public String username;
        public int color; // ARGB packed int
        public boolean enabled;

        public FriendEntry() {}

        public FriendEntry(String username, int color) {
            this.username = username;
            this.color = color;
            this.enabled = true;
        }

        // Helper getters for RGBA components
        public float getRed()   { return ((color >> 16) & 0xFF) / 255f; }
        public float getGreen() { return ((color >> 8)  & 0xFF) / 255f; }
        public float getBlue()  { return ((color)       & 0xFF) / 255f; }
        public float getAlpha() { return ((color >> 24) & 0xFF) / 255f; }

        public int getPackedRGB() { return color & 0x00FFFFFF; }
    }

    public static FriendConfig getInstance() {
        if (INSTANCE == null) {
            INSTANCE = load();
        }
        return INSTANCE;
    }

    public static FriendConfig load() {
        File file = CONFIG_PATH.toFile();
        if (file.exists()) {
            try (Reader reader = new FileReader(file)) {
                FriendConfig config = GSON.fromJson(reader, FriendConfig.class);
                if (config != null) {
                    INSTANCE = config;
                    return config;
                }
            } catch (IOException e) {
                System.err.println("[ClickFriend] Failed to load config: " + e.getMessage());
            }
        }
        INSTANCE = new FriendConfig();
        INSTANCE.save();
        return INSTANCE;
    }

    public void save() {
        try (Writer writer = new FileWriter(CONFIG_PATH.toFile())) {
            GSON.toJson(this, writer);
        } catch (IOException e) {
            System.err.println("[ClickFriend] Failed to save config: " + e.getMessage());
        }
    }

    // --- Utility methods ---

    public boolean isFriend(String username) {
        for (FriendEntry entry : friends) {
            if (entry.enabled && entry.username.equalsIgnoreCase(username)) {
                return true;
            }
        }
        return false;
    }

    public FriendEntry getFriend(String username) {
        for (FriendEntry entry : friends) {
            if (entry.username.equalsIgnoreCase(username)) {
                return entry;
            }
        }
        return null;
    }

    public void addFriend(String username, int color) {
        FriendEntry existing = getFriend(username);
        if (existing != null) {
            existing.color = color;
            existing.enabled = true;
        } else {
            friends.add(new FriendEntry(username, color));
        }
        save();
    }

    public void removeFriend(String username) {
        friends.removeIf(e -> e.username.equalsIgnoreCase(username));
        save();
    }

    public void toggleFriend(String username) {
        FriendEntry entry = getFriend(username);
        if (entry != null) {
            entry.enabled = !entry.enabled;
            save();
        }
    }
}
